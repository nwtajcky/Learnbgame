1. LICENCE
Texture images were made by The Grove and are copyright (c) 2014-2015 Wybren van Keulen, The Grove. Only as a customer who purchased this product, you may use this product in your personal or commercial projects. You may not redistribute this product (or part of it) in any way. You may not redistribute trees incorporating this product (or part of it).

2. ABOUT
In this folder you will find a collection of seamless bark textures to finish your tree branches in a realistic way. As are the Grove�s twig textures, these bark textures were captured with accurate color and reflectivity in mind. Correct white balance and exposure relative to surfaces of known reflectance make for quality assets that can be used without tweaking. Using quality HDRI lighting together with the Grove provides instant realism.

3. USAGE
The name of the tree species is followed by a number. This number tells you the estimated thickness of the trunk.

For information on this product, visit https://www.thegrove3d.com
For questions about this product, contact info@thegrove3d.com

Have fun growing!